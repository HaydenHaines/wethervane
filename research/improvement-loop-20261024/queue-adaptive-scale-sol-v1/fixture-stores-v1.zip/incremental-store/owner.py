
import hashlib,json,pathlib,sys,time
output,mode=pathlib.Path(sys.argv[1]),sys.argv[2]
output.mkdir()
value=mode
if len(sys.argv)>3:
    data=pathlib.Path(sys.argv[3]).read_bytes()
    assert hashlib.sha256(data).hexdigest()==sys.argv[4], "dependency SHA argument differs"
    receipt=json.loads(data)
    pin=receipt["data"]
    raw=pathlib.Path(pin["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==pin["sha256"]
    value=raw.decode()+":consumed"
if mode!="missing_data": (output/"data.txt").write_text(value)
if mode!="missing_receipt":
    receipt={"schema":"QueueFixtureV1","plan_sha256":"wrong" if mode=="wrong_metadata" else "fixed-plan","status":"computed","data":{"path":str(output/"data.txt"),"sha256":hashlib.sha256(value.encode()).hexdigest(),"size":len(value.encode())}}
    (output/"receipt.json").write_text(json.dumps(receipt))
    (output/"second.json").write_text(json.dumps(dict(receipt,variant="second")))
if mode=="hold": time.sleep(60)
if mode=="nonzero": sys.exit(7)
